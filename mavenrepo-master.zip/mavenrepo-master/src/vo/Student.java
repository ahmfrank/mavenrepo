package vo;

public class Student {
	private int studentId;
	private String studentName;
	private String studentAddr;
	private String age;
	private String qualification;
	private String percentage;
	private String yearPassed;
	
	public Student(){}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentAddr() {
		return studentAddr;
	}

	public void setStudentAddr(String studentAddr) {
		this.studentAddr = studentAddr;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}

	public String getYearPassed() {
		return yearPassed;
	}

	public void setYearPassed(String yearPassed) {
		this.yearPassed = yearPassed;
	}

	
}
 